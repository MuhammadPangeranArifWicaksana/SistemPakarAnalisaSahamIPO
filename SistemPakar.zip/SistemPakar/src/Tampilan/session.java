/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tampilan;

/**
 *
 * @author muham
 */
public class session {
    private static String iduser;
    private static String email;
    private static String username;
    private static String password;   
    
    public static String get_iduser(){
        return iduser;
    }
    public static void set_iduser(String iduser){
        session.iduser = iduser;
    }
    
    public static String get_email(){
        return email;
    }
    public static void set_email(String email){
        session.email = email;
    }
    
    public static String get_username(){
        return username;
    }
    public static void set_username(String username){
        session.username = username;
    }
    
    public static String get_password(){
        return password;
    }
    public static void set_password(String password){
        session.password = password;
    }
}
