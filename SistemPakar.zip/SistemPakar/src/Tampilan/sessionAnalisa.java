/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tampilan;

/**
 *
 * @author muham
 */
public class sessionAnalisa {
    private static String dtKodeEmiten;
    private static String dtNamaPerusahaan;
    private static String dtSektorPerusahaan;   
    private static String dtTahun; 
    private static String dtHargaSaham; 
    private static String dtJumlahSaham; 
    private static String dtHutang; 
    private static String dtLaba; 
    private static String dtRoe; 
    private static String dtDer; 
    private static String dtPer; 
    private static String dtPbv; 
    private static String dtHargaWajar; 
    private static String Kesimpulan; 
    private static String roeKes; 
    private static String derKes; 
    private static String perKes; 
    private static String pbvKes; 
    private static String hargaWajarKes; 
    private static String dtKapPasar; 
    private static String dtEkuitas;
    private static String id;
    private static String iduser;
    private static String eps;
    private static String bv;
    
    public static String get_dtKodeEmiten(){
        return dtKodeEmiten;
    }
    public static void set_dtKodeEmiten(String dtKodeEmiten){
        sessionAnalisa.dtKodeEmiten = dtKodeEmiten;
    }
    
    public static String get_dtNamaPerusahaan(){
        return dtNamaPerusahaan;
    }
    public static void set_dtNamaPerusahaan(String dtNamaPerusahaan){
        sessionAnalisa.dtNamaPerusahaan = dtNamaPerusahaan;
    }
    
    public static String get_dtSektorPerusahaan(){
        return dtSektorPerusahaan;
    }
    public static void set_dtSektorPerusahaan(String dtSektorPerusahaan){
        sessionAnalisa.dtSektorPerusahaan = dtSektorPerusahaan;
    }
    
    public static String get_dtTahun(){
        return dtTahun;
    }
    public static void set_dtTahun(String dtTahun){
        sessionAnalisa.dtTahun = dtTahun;
    }
    
    public static String get_dtHargaSaham(){
        return dtHargaSaham;
    }
    public static void set_dtHargaSaham(String dtHargaSaham){
        sessionAnalisa.dtHargaSaham = dtHargaSaham;
    }
    
    public static String get_dtJumlahSaham(){
        return dtJumlahSaham;
    }
    public static void set_dtJumlahSaham(String dtJumlahSaham){
        sessionAnalisa.dtJumlahSaham = dtJumlahSaham;
    }
    
    public static String get_dtHutang(){
        return dtHutang;
    }
    public static void set_dtHutang(String dtHutang){
        sessionAnalisa.dtHutang = dtHutang;
    }
    
    public static String get_dtLaba(){
        return dtLaba;
    }
    public static void set_dtLaba(String dtLaba){
        sessionAnalisa.dtLaba = dtLaba;
    }
    
    public static String get_dtRoe(){
        return dtRoe;
    }
    public static void set_dtRoe(String dtRoe){
        sessionAnalisa.dtRoe = dtRoe;
    }
    
    public static String get_dtDer(){
        return dtDer;
    }
    public static void set_dtDer(String dtDer){
        sessionAnalisa.dtDer = dtDer;
    }
    
    public static String get_dtPer(){
        return dtPer;
    }
    public static void set_dtPer(String dtPer){
        sessionAnalisa.dtPer = dtPer;
    }
    
    public static String get_dtPbv(){
        return dtPbv;
    }
    public static void set_dtPbv(String dtPbv){
        sessionAnalisa.dtPbv = dtPbv;
    }
    
    public static String get_dtHargaWajar(){
        return dtHargaWajar;
    }
    public static void set_dtHargaWajar(String dtHargaWajar){
        sessionAnalisa.dtHargaWajar = dtHargaWajar;
    }
    
    public static String get_Kesimpulan(){
        return Kesimpulan;
    }
    public static void set_Kesimpulan(String Kesimpulan){
        sessionAnalisa.Kesimpulan = Kesimpulan;
    }
    
    public static String get_roeKes(){
        return roeKes;
    }
    public static void set_roeKes(String roeKes){
        sessionAnalisa.roeKes = roeKes;
    }
    
    public static String get_derKes(){
        return derKes;
    }
    public static void set_derKes(String derKes){
        sessionAnalisa.derKes = derKes;
    }
    
    public static String get_perKes(){
        return perKes;
    }
    public static void set_perKes(String perKes){
        sessionAnalisa.perKes = perKes;
    }
    
    public static String get_pbvKes(){
        return pbvKes;
    }
    public static void set_pbvKes(String pbvKes){
        sessionAnalisa.pbvKes = pbvKes;
    }
    
    public static String get_hargaWajarKes(){
        return hargaWajarKes;
    }
    public static void set_hargaWajarKes(String hargaWajarKes){
        sessionAnalisa.hargaWajarKes = hargaWajarKes;
    }
    
    public static String get_dtKapPasar(){
        return dtKapPasar;
    }
    public static void set_dtKapPasar(String dtKapPasar){
        sessionAnalisa.dtKapPasar = dtKapPasar;
    }
    
    public static String get_dtEkuitas(){
        return dtEkuitas;
    }
    public static void set_dtEkuitas(String dtEkuitas){
        sessionAnalisa.dtEkuitas = dtEkuitas;
    }
    
    public static String get_id(){
        return id;
    }
    public static void set_id(String id){
        sessionAnalisa.id = id;
    }
    
    public static String get_iduser(){
        return iduser;
    }
    public static void set_iduser(String iduser){
        sessionAnalisa.iduser = iduser;
    }
    
    public static String get_eps(){
        return eps;
    }
    public static void set_eps(String eps){
        sessionAnalisa.eps = eps;
    }
    
    public static String get_bv(){
        return bv;
    }
    public static void set_bv(String bv){
        sessionAnalisa.bv = bv;
    }
}
