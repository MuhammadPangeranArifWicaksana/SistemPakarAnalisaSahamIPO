/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistempakar;
import Tampilan.FormMasuk;

/**
 *
 * @author muham
 */
public class AplikasiSistemPakarAnalisaSahamIPO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        FormMasuk loginFrame = new FormMasuk();
    
    // Mengatur halaman login sebagai frame utama
    javax.swing.SwingUtilities.invokeLater(() -> {
        loginFrame.setVisible(true);
    });
}
    
    
}
